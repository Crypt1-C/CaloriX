import { motion } from "motion/react";
import { Heart, Plus, TrendingUp, Award } from "lucide-react";
import { RecipeCard } from "./RecipeCard";

const favoriteRecipes = [
  {
    title: "Truffle Mushroom Risotto",
    image: "https://images.unsplash.com/photo-1763867641141-50e00520f189?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    calories: 380,
    time: 35,
    rating: 4.9
  },
  {
    title: "Grilled Salmon",
    image: "https://images.unsplash.com/photo-1774921676942-90c6cfe9d541?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    calories: 420,
    time: 25,
    rating: 4.8
  },
  {
    title: "Fresh Spring Salad",
    image: "https://images.unsplash.com/photo-1769816042376-e7b16f728013?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    calories: 220,
    time: 15,
    rating: 4.7
  }
];

export function UserDashboard({ onRecipeClick }: { onRecipeClick?: (recipe: any) => void }) {
  return (
    <div className="py-20 px-6">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-4xl md:text-5xl text-[var(--beige)] mb-2" style={{ fontWeight: 700 }}>
                My Kitchen
              </h2>
              <p className="text-lg text-[var(--muted-foreground)]">
                Your personal recipe collection and cooking stats
              </p>
            </div>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-6 py-3 bg-[var(--orange)] text-[var(--black)] rounded-full flex items-center gap-2 hover:shadow-xl hover:shadow-[rgba(255,107,53,0.3)] transition-all"
              style={{ fontWeight: 600 }}
            >
              <Plus className="w-5 h-5" />
              Add Recipe
            </motion.button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              whileHover={{ y: -4 }}
              className="bg-[var(--glass-bg)] backdrop-blur-md border border-[var(--glass-border)] rounded-2xl p-6"
            >
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-full bg-[rgba(255,107,53,0.2)] flex items-center justify-center">
                  <Heart className="w-7 h-7 text-[var(--orange)]" />
                </div>
                <div>
                  <div className="text-3xl text-[var(--beige)]" style={{ fontWeight: 700 }}>
                    47
                  </div>
                  <div className="text-[var(--muted-foreground)]">Saved Recipes</div>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              whileHover={{ y: -4 }}
              className="bg-[var(--glass-bg)] backdrop-blur-md border border-[var(--glass-border)] rounded-2xl p-6"
            >
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-full bg-[rgba(26,58,46,0.5)] flex items-center justify-center">
                  <TrendingUp className="w-7 h-7 text-[var(--beige)]" />
                </div>
                <div>
                  <div className="text-3xl text-[var(--beige)]" style={{ fontWeight: 700 }}>
                    12
                  </div>
                  <div className="text-[var(--muted-foreground)]">Recipes Shared</div>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3 }}
              whileHover={{ y: -4 }}
              className="bg-[var(--glass-bg)] backdrop-blur-md border border-[var(--glass-border)] rounded-2xl p-6"
            >
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-full bg-[rgba(255,107,53,0.2)] flex items-center justify-center">
                  <Award className="w-7 h-7 text-[var(--orange)]" />
                </div>
                <div>
                  <div className="text-3xl text-[var(--beige)]" style={{ fontWeight: 700 }}>
                    4.8
                  </div>
                  <div className="text-[var(--muted-foreground)]">Avg. Rating</div>
                </div>
              </div>
            </motion.div>
          </div>
        </motion.div>

        <div className="mb-12">
          <h3 className="text-2xl text-[var(--beige)] mb-6" style={{ fontWeight: 600 }}>
            Favorite Recipes
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {favoriteRecipes.map((recipe, index) => (
              <RecipeCard
                key={index}
                {...recipe}
                delay={index * 0.1}
                onClick={() => onRecipeClick?.(recipe)}
              />
            ))}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-[var(--glass-bg)] backdrop-blur-md border border-[var(--glass-border)] rounded-2xl p-8"
        >
          <h3 className="text-2xl text-[var(--beige)] mb-6" style={{ fontWeight: 600 }}>
            Personalized Suggestions
          </h3>
          <p className="text-[var(--muted-foreground)] mb-6">
            Based on your ingredients: Chicken, Tomatoes, Garlic, Pasta, Olive Oil
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {['Chicken Marinara', 'Garlic Pasta Aglio', 'Tomato Basil Chicken', 'Mediterranean Pasta'].map((suggestion, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ x: 4 }}
                className="flex items-center justify-between p-4 bg-[rgba(26,58,46,0.3)] border border-[var(--glass-border)] rounded-xl cursor-pointer hover:border-[var(--orange)] transition-colors"
              >
                <span className="text-[var(--beige)]">{suggestion}</span>
                <span className="text-[var(--orange)]">→</span>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
