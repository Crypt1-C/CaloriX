import { useState } from "react";
import { Navigation } from "./components/Navigation";
import { HeroSection } from "./components/HeroSection";
import { SearchSection } from "./components/SearchSection";
import { PopularRecipes } from "./components/PopularRecipes";
import { WatchAndCook } from "./components/WatchAndCook";
import { UserDashboard } from "./components/UserDashboard";
import { Footer } from "./components/Footer";
import { AuthModal } from "./components/AuthModal";
import { RecipeDetailModal } from "./components/RecipeDetailModal";
import { ScrollToTop } from "./components/ScrollToTop";
import { FeatureHighlights } from "./components/FeatureHighlights";
import { CTASection } from "./components/CTASection";

export default function App() {
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [selectedRecipe, setSelectedRecipe] = useState<any>(null);

  const heroRecipe = {
    title: "Truffle Mushroom Risotto",
    image: "https://images.unsplash.com/photo-1763867641141-50e00520f189?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    calories: 380,
    time: 35,
    rating: 4.9,
    servings: 4
  };

  return (
    <div className="min-h-screen bg-[var(--background)]">
      <Navigation onAuthClick={() => setIsAuthModalOpen(true)} />

      <HeroSection onGetRecipe={() => setSelectedRecipe(heroRecipe)} />

      <SearchSection />

      <PopularRecipes onRecipeClick={setSelectedRecipe} />

      <WatchAndCook />

      <FeatureHighlights />

      {!isLoggedIn && <CTASection onSignUpClick={() => setIsAuthModalOpen(true)} />}

      {isLoggedIn && <UserDashboard onRecipeClick={setSelectedRecipe} />}

      <Footer />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />

      <RecipeDetailModal
        isOpen={!!selectedRecipe}
        onClose={() => setSelectedRecipe(null)}
        recipe={selectedRecipe || heroRecipe}
      />

      <ScrollToTop />
    </div>
  );
}